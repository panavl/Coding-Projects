"""
Pokemon Battle Simulator

  File: pokemon_final.py
  Description:

  Student Name: Wei-Yu Chiang
  Student UT EID: wc22968

  Partner Name: Panav Ladha
  Partner UT EID: pl22793

  Course Name: CS 313E
  Unique Number:
  Date Created: 11/16/2023
  Date Last Modified: 11/27/2023

"""

import csv
import random


class Pokemon:
    """Class representing a Pokemon."""

    def __init__(self, index_number, name, poke_type, moves):
        """Initialize Pokemon attributes."""
        self.index_number = index_number
        self.name = name
        self.type = poke_type
        self.max_hp = 100
        self.attack = 30
        self.health = 100
        self.moves = moves

    def take_damage(self, damage):
        """Reduce Pokemon's HP based on the received damage."""
        self.health -= damage
        if self.health < 0:
            self.health = 0


    def is_fainted(self):
        """Check if the Pokemon has fainted."""
        return self.health == 0

    def choose_move(self):
        """Prompt the user to choose a move for the Pokemon."""
        print(f"\n{self.name}'s available moves:")
        for i, move in enumerate(self.moves, start=1):
            print(f"{i}. {move}")

        while True:
            move_index = int(input("Choose a move by entering its index number: "))
            if 1 <= move_index <= len(self.moves):
                return self.moves[move_index - 1]
            print("Invalid move index. Please choose a valid move.\n")


class PokeMoves:
    """Class representing Pokemon moves."""

    def __init__(self):
        """Initialize PokeMoves attributes."""
        self.moves_by_type = {}

    def add_move(self, type_name, move_name):
        """Add a move to the moves_by_type dictionary."""
        if type_name not in self.moves_by_type:
            self.moves_by_type[type_name] = []
        self.moves_by_type[type_name].append(move_name)

    def load_moves(self, csv_path):
        """Load Pokemon moves from a CSV file."""
        with open(csv_path, 'r', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                type_name = row['Type']
                move_name = row['Name']
                self.add_move(type_name, move_name)

    def get_random_move(self, type_name):
        """Get a random move for a given Pokemon type."""
        moves = self.moves_by_type.get(type_name, [])
        return random.choice(moves) if moves else None


class PokemonGraph:
    """Class representing relationships between Pokemon types."""

    def __init__(self):
        """Initialize PokemonGraph attributes."""
        self.types = {}

    def add_type(self, type_name):
        """Add a Pokemon type to the types dictionary."""
        if type_name not in self.types:
            self.types[type_name] = {}

    def add_relationship(self, type1, type2, effectiveness):
        """Add a relationship between two Pokemon types."""
        if type1 in self.types and type2 in self.types:
            self.types[type1][type2] = effectiveness

    def load_type_advantages(self, csv_path):
        """Load type advantages from a CSV file."""
        with open(csv_path, 'r', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                attack_type = row['Attack Type']
                defense_type = row['Defense Type']
                multiplier = float(row['Multiplier'])
                self.add_type(attack_type)
                self.add_type(defense_type)
                self.add_relationship(attack_type, defense_type, multiplier)

    def calculate_type_multiplier(self, attacking_type, defending_type):
        """Calculate the type multiplier based on Pokemon types."""
        if attacking_type in self.types and defending_type in self.types[attacking_type]:
            return self.types[attacking_type][defending_type]
        return 1.0

    def calculate_damage(self, attacker, defender):
        """Calculate the damage inflicted by the attacker on the defender."""
        type_multiplier = self.calculate_type_multiplier(attacker.type, defender.type)
        random_factor = random.uniform(0.8, 1.2)
        damage = int((attacker.attack) * (random_factor) * type_multiplier)
        return damage


class PokemonList:
    """Class representing a list of Pokemon."""

    def __init__(self):
        """Initialize PokemonList attributes."""
        self.pokemon_list = []

    def load_pokemons(self, csv_path, pokemon_moves):
        """Load Pokemon data from a CSV file."""
        with open(csv_path, newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)
            for row in reader:
                index_number = int(row[0])
                name = row[1]
                poke_type = row[2]
                pokemon_moves_for_type = pokemon_moves.moves_by_type.get(poke_type, [])
                self.pokemon_list.append([index_number, name, poke_type, pokemon_moves_for_type])

    def display_all_pokemon(self):
        """Display information about all Pokemon in the list."""
        print("Pokemon List:")
        for pokemon in self.pokemon_list:
            print(f"{pokemon[0]}. {pokemon[1]} ({pokemon[2]})")
        print("")

    def linear_search_pokemon(self, name):
        """Perform a linear search for a Pokemon by name."""
        name_lower = name.strip().lower()
        for pokemon in self.pokemon_list:
            if pokemon[1].strip().lower() == name_lower:
                return pokemon
        return None

    def choose_pokemon(self):
        """Prompt the user to choose a Pokemon."""
        print("Choose an option:")
        print("1. See all Pokemon options and choose by PokeIndex")
        print("2. Enter a Pokemon name")

        while True:
            option = input("Enter the option number: ")
            if option == '1':
                self.display_all_pokemon()
                while True:
                    chosen_index = int(input("Choose a Pokemon by entering its index number: "))
                    chosen_pokemon_data = next((pokemon for pokemon in self.pokemon_list
                                                if pokemon[0] == chosen_index), None)
                    if chosen_pokemon_data:
                        chosen_pokemon = Pokemon(chosen_pokemon_data[0], chosen_pokemon_data[1],
                                                  chosen_pokemon_data[2], chosen_pokemon_data[3])
                        print(f"Chosen Pokemon: {chosen_pokemon.name} ({chosen_pokemon.type})")
                        return chosen_pokemon
                    print("Invalid index number. Please choose a valid Pokemon.")
            elif option == '2':
                while True:
                    name_choice = input("Enter a Pokemon name: ")
                    chosen_pokemon_data = self.linear_search_pokemon(name_choice)
                    if chosen_pokemon_data:
                        chosen_pokemon = Pokemon(chosen_pokemon_data[0], chosen_pokemon_data[1],
                                                  chosen_pokemon_data[2], chosen_pokemon_data[3])
                        print(f"Chosen Pokemon: {chosen_pokemon.name} ({chosen_pokemon.type})")
                        return chosen_pokemon
                    print("Invalid name. Please enter a valid Pokemon name.")
            else:
                print("\nInvalid option. Please choose a valid option.")
                print("1. See all Pokemon options and choose by PokeIndex")
                print("2. Enter a Pokemon name")


def battle(pokemon1, pokemon2, moves):
    """Simulate a battle between two Pokemon."""
    print(f"A battle between {pokemon1.name} ({pokemon1.type}) "
          f"and {pokemon2.name} ({pokemon2.type}) begins!")

    pokemon_graph = PokemonGraph()
    pokemon_graph.load_type_advantages('type_advantages.csv')

    while True:
        # Pokemon 1 attacks Pokemon 2
        pokemon1_move = pokemon1.choose_move()
        damage_to_pokemon2 = pokemon_graph.calculate_damage(pokemon1, pokemon2)
        pokemon2.take_damage(damage_to_pokemon2)
        type_multiplier = pokemon_graph.calculate_type_multiplier(pokemon1.type, pokemon2.type)

        effectiveness_message = ""
        if type_multiplier > 1.0:
            effectiveness_message = "It's Super Effective!"
        elif type_multiplier < 1.0:
            effectiveness_message = "It's Not Very Effective!"

        print(f"\nYour {pokemon1.name} used {pokemon1_move}! {pokemon2.name} "
              f"took {damage_to_pokemon2} damage. {effectiveness_message}")

        if pokemon2.is_fainted():
            print(f"{pokemon2.name} fainted! {pokemon1.name} wins!")
            break

        # Pokemon 2 attacks Pokemon 1
        pokemon2_move = moves.get_random_move(pokemon2.type)
        damage_to_pokemon1 = pokemon_graph.calculate_damage(pokemon2, pokemon1)
        pokemon1.take_damage(damage_to_pokemon1)
        type_multiplier = pokemon_graph.calculate_type_multiplier(pokemon2.type, pokemon1.type)

        effectiveness_message = ""
        if type_multiplier > 1.0:
            effectiveness_message = "It's Super Effective!"
        elif type_multiplier < 1.0:
            effectiveness_message = "It's Not Very Effective!"

        print(f"The opponent's {pokemon2.name} used {pokemon2_move}! {pokemon1.name} "
              f"took {damage_to_pokemon1} damage. {effectiveness_message}\n")

        if pokemon1.is_fainted():
            print(f"{pokemon1.name} fainted! {pokemon2.name} wins!")
            break

        print(f"{pokemon1.name}'s HP: {pokemon1.health}/{pokemon1.max_hp} | {pokemon2.name}'s "
              f"HP: {pokemon2.health}/{pokemon2.max_hp}")

        while True:
            continue_battle = input("Continue the battle? (yes/no): ").lower()
            if continue_battle in ('yes', 'no'):
                break
            print("Invalid input. Please enter 'yes' or 'no'.")

        if continue_battle == 'no':
            print("The battle ended.")
            break


def main():
    """Main function to run the Pokemon Simulator."""
    # Load Pokemon moves and types
    pokemon_moves = PokeMoves()
    pokemon_moves.load_moves('poke_moves.csv')

    # Load Pokemon list
    pokemons = PokemonList()
    pokemons.load_pokemons('Pokemon.csv', pokemon_moves)

    # Choose Pokemon for the battle
    print("Welcome to Pokemon Simulator. Please choose two Pokemons to battle each other.\n")
    print("First choose your Pokemon")

    pokemon1 = pokemons.choose_pokemon()
    print("")
    print("Now choose your opponent's Pokemon.")
    pokemon2 = pokemons.choose_pokemon()

    # Start the battle
    battle(pokemon1, pokemon2, pokemon_moves)


if __name__ == "__main__":
    main()
